<template>
    <div class="flex flex-col justify-center items-center bg min-h-screen py-10">
        <router-link to="/Page" class="self-start bg-[#022511] py-2 px-6 ml-10 mb-4 rounded-lg">
            <img src="../../assets/img/exit.png" alt="Back" >
        </router-link>
        <div class="container flex flex-col justify-center items-center">
            <div>
                <img src="../../assets/img/bez.jpg" alt="Image" class="w-[600px]">
            </div>
            <div class="flex items-center justify-center">
                <p class="max-w-[70%] text-xl font-medium text-[#14532D] mt-5">
                    Eng keng tarqalgan, oshqozon osti bezi adenokarsinomasi hisoblanib, oshqozon osti saratonlarining
                    taxminan 90% holatlarini tashkil qiladi[3] va „oshqozon osti bezi saratoni“ atamasi baʼzan faqat shu
                    turga nisbatan qoʻllaniladi[2]. Ushbu adenokarsinomalar oshqozon osti bezining ovqat hazm qilishga
                    yordam beradigan fermentlarini ishlab chiqaradigan qismida paydo boʻla boshlaydi[2]. Oshqozon osti bezi
                    saratonining taxminan 1-2% neyroendokrin oʻsmalar boʻlib, ular oshqozon osti bezining gormon ishlab
                    chiqaradigan hujayralaridan kelib chiqadi[2]. Ular odatda pankreatik adenokarsinomaga qaraganda xavfsiz
                    hisoblanadi[2].

                    Oshqozon osti bezi saratonining eng keng tarqalgan shaklining belgilariga sargʻish teri, qorin yoki bel
                    ogʻrigʻi, sababsiz vazn yoʻqotish, och rangli najas, quyuq siydik va ishtahani yoʻqolishi kiradi[4].
                    Odatda, kasallikning dastlabki bosqichlarida hech qanday alomatlar koʻzga tashlanmaydi va oshqozon osti
                    bezi saratoni tashhisini qoʻyish uchun yetarlicha oʻziga xos belgilar kasallikning rivojlangan bosqichga
                    yetgunga qadar yaqqol bilinmaydi[4][5]. Tashxis qoʻyish vaqtida oshqozon osti bezi saratoni koʻpincha
                    tananing boshqa qismlariga metastaz bergani aniqlanadi
                </p>
            </div>
        </div>
    </div>
</template>
  
<script>
export default {}
</script>
  
<style scoped>

</style>
  