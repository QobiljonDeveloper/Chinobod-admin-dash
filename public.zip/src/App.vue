<template>
  <div>
    <router-view />
  </div>
</template>

<script>
export default {
  components: {
  }
}
</script>

<style>
/* Any additional styles */
</style>
